<?php

    /*
    * HLL RSS
    *    
    * Jednoduchy skript pro parsnuti klubu z Hofylandu a jejich prevod na RSS feed.
    * Podporuje dva mody:
    *  ?club=<ID_KLUBU> - RSS feed poslednich prispevku verejneho klubu
    *  ?user=<NICKNAME>&pass=<PASSWORD> - RSS feed poslednich prispevku z klubu v BOOKu (vcetne neverejnych)
    *
    * BUGS:
    * Na nekterych serverech nefunguje prihlasovani a tim padem ani vypis BOOKu. Pravdepodobne
    * to zavisi na nastaveni PHP.
    *
    */

    header('Content-type: application/rss+xml');
    include "ganon.php"; // knihovna pro parsovani HTML DOMu
    $SESSION_HASH = NULL;
    $USER_NAME = NULL;
    $USER_PASS = NULL;

    // stahnout stranku klubu
    function getClubPage($club_id) {
        global $SESSION_HASH;
        $url = "http://www.hofyland.cz/?club&klub=".$club_id.($SESSION_HASH?"&login=".$SESSION_HASH:"");
        return file_get_contents( $url );
    }

    // stahnout stranku BOOKu uzivatele
    function getBookPage($user_name, $user_pass) {
        global $SESSION_HASH;

        $post_data = array(
            'hlnick'=>$user_name,
            'hlpsw'=>$user_pass,
            'send_hlprihlaseni'=>'Přihlásit',
            //'hllip'=>'1',
            'hlform'=>'true');
        $stream_options = array(
            'http' => array(
            'method'  => 'POST',
            'header'  => 'Content-type: application/x-www-form-urlencoded' . "\r\n",
            'content' =>  http_build_query($post_data)));

        $url = "http://www.hofyland.cz/index.php";
        $context  = stream_context_create($stream_options);
        $main_page = file_get_contents( $url, null, $context);
        $html = str_get_dom($main_page);
        $SESSION_HASH = array_pop(explode("=",$html->select('meta[http-equiv="REFRESH"]',0)->content));

        $book_page = file_get_contents("http://www.hofyland.cz/?book&login=".$SESSION_HASH);
        return $book_page;
    }

    // stahnout posledni prispevky z daneho klubu a vratit jejich pole
    function parseClub($club_id, $club_name=NULL) {
        $page = getClubPage($club_id);
        $html = str_get_dom($page);
        $title=($club_name?$club_name:$html->select('div[class="nadpis"]',0)->getPlainText());
        $link="http://www.hofyland.cz/?club&klub=".$club_id;
        $posts = Array();
        foreach($html->select('div[class="rowp"]') as $index => $element) {
            $post = Array();
            $post['author']=trim($element->select('span[class="nickpost"]',0)->getPlainText());
             // preskocit prispevky uzivatele "REKLAMA"
            if ( $post['author'] == "REKLAMA" ) continue;

            $post_date = $element->select('span[class="datepost"]',0)->getPlainText();
            // bezva hofy spek - datum u prispevku se lisi pro prihlasene a anonymni navstevniky
            if ( strpos($post_date,":")<strpos($post_date,".") ) 
                list($hour,$min,$sec,$day,$month,$year) = sscanf($post_date, " %d:%d:%d %d.%d.%d ");
            else
                list($day,$month,$year,$hour,$min,$sec) = sscanf($post_date, " %d.%d.%d %d:%d:%d ");
            $post['timestamp']=strtotime(sprintf("%d/%d/%d %d:%d:%d",$year,$month,$day,$hour,$min,$sec));
            $post['date']=date("D, d M Y H:i:s ",$post['timestamp'])."EST";
            $post['category']=$title;
            $post['text']=$element->select('td[class="txtpost"]',0)->getInnerText();
            $post['link']=$link;

            $posts[] = $post;
        }

        return $posts;
    }

    // stahnout seznam klubu, ktere ma uzivatel v BOOKu, vrati pole [ club_id => club_name , ... ]
    function parseUser($user_name, $user_pass) {
        $page = getBookPage($user_name,$user_pass);
        $html = str_get_dom($page);
        $clubs = Array();
        foreach($html->select('div[class="bookrow"]') as $element) {
            $club_name = $element->select('a[class="klub"]',0)->getPlainText();
            sscanf( $element->select('a[class="klub"]',0)->href, "?club&amp;klub=%d&amp;", $club_id );
            $clubs[$club_id] = $club_name;
        }
        return $clubs;
    }

    // URL aktualni stranky
    function curPageURL() {
        $pageURL = 'http';
        if ($_SERVER["HTTPS"] == "on") {$pageURL .= "s";}
            $pageURL .= "://";
        if ($_SERVER["SERVER_PORT"] != "80") {
            $pageURL .= $_SERVER["SERVER_NAME"].":".$_SERVER["SERVER_PORT"].$_SERVER["REQUEST_URI"];
        } else {
            $pageURL .= $_SERVER["SERVER_NAME"].$_SERVER["REQUEST_URI"];
        }
        $pageURL_split = explode("?",$pageURL);
        return $pageURL_split[0];
    }

    // V sablonovem HTML nahradit {$var} hodnotami promennych
    function useTemplate($template, $data, $isLoop = False ) {
        if ( $isLoop ) {
            $fragment = $data;
        } else {
            $fragment = array( $data );
            $template = file_get_contents($template);
        }

        $compiled = "";
        foreach ($fragment as $data ) {
            $compiled_item = $template;
        
            // process loops
            $compiled_item = preg_replace("/{loop\\$([^}]*)}"."(.*)"."{endloop}/es","useTemplate('\\2',\$data['\\1'], True)",$compiled_item);
    
            // replace variables
            $compiled_item = preg_replace("/{\\$([^}]*)}/e","\$data['\\1']",$compiled_item);

            $compiled .= $compiled_item;
        }

        return $compiled;
    }

    function comparePosts($a, $b) {
        return $a['timestamp']<$b['timestamp'];
    }    
    function sortPostsByTimestamp($items) {
        usort($items, "comparePosts");
        return $items;
    }

    // vratit RSS feed poslednich prispevku klubu
    function processClub($id) {
        $items = parseClub($id);
        $items = sortPostsByTimestamp($items);
        $data = array(
            "title"=>"HL things",
            "description"=>"some stuf...",
            "link"=>curPageURL(),
            "item"=>$items
        );
        return useTemplate("rss.xml",$data);
    }

    // vratit RSS feed poslednich prispevku z klubu v BOOKu
    function processUser($user_name, $user_pass) {
        $clubs = parseUser($user_name, $user_pass);
        $items = array();
        foreach ($clubs as $club_id=>$club_name) {
            $club_items = parseClub($club_id, $club_name);
            $items = array_merge($items, $club_items);
        }
        $items = sortPostsByTimestamp($items);

        $data = array(
            "title"=>"HofyLand",
            "description"=>"Posledni prispevky v klubech z boku uzivatele $id",
            "link"=>curPageURL(),
            "item"=>$items
        );

        return useTemplate("rss.xml",$data);
    }

    if ($_GET['club']!=NULL)
        echo processClub( $_GET['club'] );
    else
        echo processUser( $_GET['user'], $_GET['pass'] );

?>


